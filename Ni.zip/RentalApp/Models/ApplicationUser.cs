﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;

namespace RentalApp.Models
{
    public class ApplicationUser : IdentityUser
    {
        // dodatkowe pola (opcjonalnie), np. FirstName, LastName itp.
    }
}
